#define GRAPHICS_H

void draw(ui_t *ui, game_t *game);
