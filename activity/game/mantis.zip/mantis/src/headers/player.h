#define PLAYER_H

player_t *create_player();
int mcts(game_t *game);