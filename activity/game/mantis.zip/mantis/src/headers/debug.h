#define DEBUG_H

void print_node_id(node_id_t id);
void debug_print_id(game_t *game);
void print_all_players_tank(game_t *game);